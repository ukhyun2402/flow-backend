# Generated Python server

Python 3.12+: `pip install -r requirements.txt`, then `uvicorn app:app --port 8080`.
Set FLOW_RUNTIME_TOKEN for bearer APIs. Copy config/databases.example.json to an external config, set FLOW_DATABASE_CONFIG and provide passwordSecretRef environment variables. No management APIs are included.

Tibero requires a vendor ODBC driver and DSN installed in the target OS. Verify redistribution permissions separately. Dockerfile does not bundle this driver. Keep user code in extensions/ and export into a fresh directory.
