Validate API fixtures against schemas/ and openapi.json. Run DB integration checks in the target environment; do not invoke production write flows as smoke tests.
