Run API contract checks against openapi.json and schemas/. Integration against the target DB remains required.
