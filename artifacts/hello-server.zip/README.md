# Generated Flow Server

Build: `mvn package` (JDK 17+, Maven 3.6.3+). Run from this directory: `java -jar target/flow-platform-0.1.0.jar`.

Set FLOW_RUNTIME_TOKEN for bearer authentication. Set FLOW_DATABASE_CONFIG to an external JSON configuration file and provide its passwordSecretRef as an environment variable. No platform management APIs are included.

Docker: `docker build -t generated-flow .`. Mount DB configuration read-only; inject secrets at runtime. Tibero requires an externally supplied vendor JDBC JAR and classpath launch (see platform support matrix).

Keep extensions in `extensions/`; export into a fresh directory and merge only generated paths. Changes to generated Java are not imported into Flow.
